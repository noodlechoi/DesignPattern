package headfirst.designpatterns.combining.adapter;

public interface Quackable {
	public void quack();
}
