package headfirst.designpatterns.combining.ducks;

public interface Quackable {
	public void quack();
}
