package headfirst.designpatterns.factory.pizzaaf;

public class RedPepper implements Veggies {

	public String toString() {
		return "Red Pepper";
	}
}
